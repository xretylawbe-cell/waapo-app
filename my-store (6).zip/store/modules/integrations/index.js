exports.name = 'integrations';
exports.mount = (app, { cfg, auth, db, telegram }) => {
  const A = auth.requireAdmin;
  app.get('/api/admin/integrations', A, async (_q, res) => {
    let tg = { status: 'Not configured', detail: 'Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in your host settings.' };
    if (telegram.configured()) {
      try {
        const me = await telegram.call('getMe');
        tg = telegram.ready() ? { status: telegram.state.lastError ? 'Connected, last alert failed' : 'Connected', detail: `Bot @${me.username}${telegram.state.lastError ? ' – ' + telegram.state.lastError : ''}` } : { status: 'Token set, chat ID missing', detail: 'Message your bot, then use "Find chat ID".' };
      } catch { tg = { status: 'Error', detail: 'Telegram rejected the bot token.' }; }
    }
    const [w] = await db.query("SELECT value FROM settings WHERE key='whatsapp_number'");
    res.json([
      { name: 'Paystack', ...(cfg.paystackKey ? { status: 'Configured', detail: cfg.paystackKey.startsWith('sk_test') ? 'Test mode' : 'Live mode' } : { status: 'Not configured', detail: 'Set PAYSTACK_SECRET_KEY' }) },
      { name: 'Telegram', ...tg },
      { name: 'Image storage', ...(cfg.supabaseUrl && cfg.supabaseKey ? { status: 'Supabase Storage', detail: 'Bucket ' + cfg.supabaseBucket } : { status: 'Local disk', detail: 'Images are lost when free hosts restart. Set the SUPABASE_* variables.' }) },
      { name: 'WhatsApp', status: w?.value ? 'Number saved' : 'Not set', detail: 'Edit it under Content > Store settings.' },
      { name: 'Facebook/Meta', status: 'Product feed only', detail: 'Use /feeds/meta.csv in Commerce Manager. There is no direct account connection yet.' },
      { name: 'Google Sheets', status: 'Not built', detail: 'Planned.' },
    ]);
  });
  app.post('/api/admin/integrations/telegram/test', A, async (_q, res) => {
    if (!telegram.ready()) return res.status(400).json({ error: 'Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID first' });
    const ok = await telegram.send('Test message from your store admin. Order alerts are working.');
    res.json({ ok, error: ok ? null : telegram.state.lastError });
  });
  app.get('/api/admin/integrations/telegram/chats', A, async (_q, res) => {
    if (!telegram.configured()) return res.status(400).json({ error: 'Set TELEGRAM_BOT_TOKEN first' });
    try { res.json(await telegram.chats()); } catch (e) { res.status(502).json({ error: telegram.scrub(e.message) }); }
  });
};
