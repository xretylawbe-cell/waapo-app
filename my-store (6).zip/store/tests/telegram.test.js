const test = require('node:test'), assert = require('node:assert');
const make = require('../integrations/telegram');
test('send does nothing when not configured', async () => assert.equal(await make({}).send('x'), false));
test('send posts to Telegram and records success', async () => {
  let url, body; global.fetch = async (u, o) => { url = u; body = JSON.parse(o.body); return { json: async () => ({ ok: true, result: {} }) }; };
  const t = make({ telegramToken: 'T0KEN', telegramChatId: '42' });
  assert.equal(await t.send('hello'), true); assert.match(url, /botT0KEN\/sendMessage/); assert.equal(body.chat_id, '42'); assert.equal(t.state.lastError, null);
});
test('failure never throws and the token is scrubbed', async () => {
  global.fetch = async () => { throw new Error('connect failed for https://api.telegram.org/botT0KEN/sendMessage'); };
  const t = make({ telegramToken: 'T0KEN', telegramChatId: '42' });
  assert.equal(await t.send('x'), false); assert.ok(!t.state.lastError.includes('T0KEN'));
});
test('chats lists unique chats', async () => {
  global.fetch = async () => ({ json: async () => ({ ok: true, result: [{ message: { chat: { id: 7, first_name: 'Ada' } } }, { message: { chat: { id: 7, first_name: 'Ada' } } }] }) });
  assert.deepEqual(await make({ telegramToken: 'T' }).chats(), [{ id: '7', name: 'Ada' }]);
});
