// Telegram order alerts. Credentials come from environment variables only (never the database or backups).
module.exports = (cfg) => {
  const state = { lastError: null, lastOk: null };
  const scrub = (m) => cfg.telegramToken ? String(m).split(cfg.telegramToken).join('***') : String(m);
  const call = async (method, body) => {
    if (!cfg.telegramToken) throw new Error('TELEGRAM_BOT_TOKEN is not set');
    const r = await fetch(`https://api.telegram.org/bot${cfg.telegramToken}/${method}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}), signal: AbortSignal.timeout(8000) });
    const d = await r.json().catch(() => ({}));
    if (!d.ok) throw new Error(d.description || 'Telegram request failed');
    return d.result;
  };
  // Never throws: a Telegram problem must not break a payment.
  const send = async (text) => {
    if (!cfg.telegramToken || !cfg.telegramChatId) return false;
    try { await call('sendMessage', { chat_id: cfg.telegramChatId, text: String(text).slice(0, 4000) }); state.lastOk = new Date().toISOString(); state.lastError = null; return true; }
    catch (e) { state.lastError = scrub(e.message); console.error('Telegram:', state.lastError); return false; }
  };
  const chats = async () => {
    const seen = new Map();
    for (const u of await call('getUpdates', { limit: 50 })) { const c = (u.message || u.channel_post || {}).chat; if (c) seen.set(c.id, c.title || [c.first_name, c.last_name].filter(Boolean).join(' ') || c.username || 'chat'); }
    return [...seen].map(([id, name]) => ({ id: String(id), name }));
  };
  return { send, call, chats, state, scrub, configured: () => !!cfg.telegramToken, ready: () => !!(cfg.telegramToken && cfg.telegramChatId) };
};
